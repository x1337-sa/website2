@extends('template.tmp')

@section('title', 'Page Title')

@section('content')



<form action="create" method="post" enctype="multipart/form-data">
{{ csrf_field() }}
  <center>
    <div class="imgcontainer">
      <img src="1234.jpg"> 
    </div>
<br>
  </center>


  
    	<label for="name">Name:</label>
        <input type="text" name="name" id="name" class="form-control">
    </p>
    <p>
    	<label for="price">Price:</label>
        <input type="text" name="price" id="price"  class="form-control">
    </p>
   
    <input type="submit" value="Add" onclick="myFunction()">
    <input type="file" name="image" id="image" />

</form>





@endsection