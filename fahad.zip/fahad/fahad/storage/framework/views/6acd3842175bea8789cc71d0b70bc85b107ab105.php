<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('content'); ?>

<script>
    function onSend()
    {

        var id=document.getElementById("id").value;
        window.location.replace("http://localhost/fahad/fahad/public/del/"+id);

        // 4

    }
</script>



  <center>
    <div class="imgcontainer">
      <img src="1234.jpg"> 
    </div>
<br>
  </center>

  
  
    	<label for="name">Id:</label>
        <input type="text" name="id" id="id" value="" class="form-control">
    </p>
    

<button onclick="onSend()">delete</button>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.tmp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>