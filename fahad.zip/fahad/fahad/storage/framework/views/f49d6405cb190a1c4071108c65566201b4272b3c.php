<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('content'); ?>



<form action="create" method="post" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>

  <center>
    <div class="imgcontainer">
      <img src="1234.jpg"> 
    </div>
<br>
  </center>


  
    	<label for="name">Name:</label>
        <input type="text" name="name" id="name" class="form-control">
    </p>
    <p>
    	<label for="price">Price:</label>
        <input type="text" name="price" id="price"  class="form-control">
    </p>
   
    <input type="submit" value="Add" onclick="myFunction()">
    <input type="file" name="image" id="image" />

</form>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.tmp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>