@extends('template.tmp')

@section('title', 'Page Title')

@section('content')



<form action="{{route('update')}}" method="post" enctype="multipart/form-data">
{{ csrf_field() }}
  <center>
    <div class="imgcontainer">
      <img src="1234.jpg"> 
    </div>
<br>
  </center>

  <input type="hidden" name="id" id="id" value="{{$product->id}}" class="form-control">
  
    	<label for="name">Name:</label>
        <input type="text" name="name" id="name" value="{{$product->name}}" class="form-control">
    </p>
    <p>
    	<label for="price">Price:</label>
        <input type="text" name="price" id="price" value="{{$product->price}}" class="form-control">
    </p>
   
    <input type="submit" value="Add" onclick="myFunction()">
    <input type="file" name="image" id="image" />

</form>




@endsection