@extends('template.tmp')

@section('title', 'Page Title')



@section('content')
    
<div class="container">
    <h1 class="mt-4"> 
    <p>Find Your New Favourite Game, Download & Play Now! Get Pulled Into The Heart Of The Action In Your PS4™. Be the first to play. </p>
    </h1>
    
  </div>
	<body>
		<br />
		
		<div class="container">
			<div class=" row">
				<br />
				<br />
				<br />
				
				<br /><br />
				@foreach ($products as $product)
				<div class="col-6 py-3">
					<form method="post">
						<div style="border:3px solid #5cb85c; background-color:whitesmoke; border-radius:5px; padding:16px;" align="center">
							<img src="storage/{{($product->image)}}" class="img-responsive" /><br />
	
							<h4 class="text-info">{{$product->name}}</h4>
	
							<h4 class="text-danger">{{$product->price}}</h4>
	
							<input type="text" name="quantity" value="1" class="form-control" />
	
							<input type="hidden" name="hidden_name" value="" />
	
							<input type="hidden" name="hidden_price" value="" />
	
							<input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Add to Cart" />
	
						</div>
					</form>
				</div>
                @endforeach

<!-- 				
				<div style="clear:both"></div>
				<br />
				<div class="col-12">

					<h3>Order Details</h3>
					<div class="table-responsive">
						<table class="table table-bordered">
							<tr>
								<th width="40%">Item Name</th>
								<th width="10%">Quantity</th>
								<th width="20%">Price</th>
								<th width="15%">Total</th>
								<th width="5%">Action</th>
							</tr>
							
							<tr>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
							</tr>
							
							
							<tr>
								<td colspan="3" align="right">Total</td>
								<td align="right">$ </td>
								<td></td>
							</tr>
							
							
							
							
								
						</table>
						<button type="button" class="btn btn-primary btn-lg btn-block">Success</button>
					</div>
				</div>
			</div> -->
			
			</div>
	</div>
    



@endsection