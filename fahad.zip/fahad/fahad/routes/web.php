<?php
use App\Product;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/index', function () {
    $products=Product::all();
    // return $products;
    return view('order.index')->with('products',$products);
});


Route::get('/add', function () {
    
    
    return view('order.orderAdd');
});

Route::get('/edit/{id}', function ($id) {
    $product=Product::find($id);

   //return $product; 
    return view('order.edit')->with('product',$product);
});

Route::post('/create', function (Request $request) {
    $product=new Product;
    $product->name=$request->name;
    $product->price=$request->price;

    $img=Storage::disk('public')->put('image/', $request->file('image'));
    $product->image=$img;
    if($product->save())
    {
        return 'success';
    }
    return 'there is some error';
});


Route::post('/update', function (Request $request) {
    $product=Product::find($request->id);
    $product->name=$request->name;
    $product->price=$request->price;


    $img=Storage::disk('public')->put('image/', $request->file('image'));
    $product->image=$img;
    if($product->save())
    {
        return 'success';
    }
    return 'there is some error';


})->name('update');



Route::get('/delete', function () {
    

//    
    return view('order.del');
});
Route::get('/del/{id}', function ($id) {
    $product=Product::find($id);

    if($product->delete())
    {
        return "deleted";
    }
    return "error";

//    //return $product; 
//     return view('order.del')->with('product',$product);
});
